export class Item {
  _id: string
  description: string
  done: boolean
}
